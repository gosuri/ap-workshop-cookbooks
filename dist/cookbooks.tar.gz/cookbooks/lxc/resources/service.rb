actions :start, :stop, :halt, :restart, :freeze, :unfreeze
default_action :start

attribute :service_name, :kind_of => String

