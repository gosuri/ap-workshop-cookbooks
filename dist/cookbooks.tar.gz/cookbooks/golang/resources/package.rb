actions :install, :update, :build
default_action :install

attribute :name, :kind_of => String, :name_attribute => true
