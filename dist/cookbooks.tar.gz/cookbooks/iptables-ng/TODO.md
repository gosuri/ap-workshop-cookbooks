# TODO

Automatically translate whitespaces (and other non-filename characters) into underscores in
iptables\_ng\_rule name attribute.
