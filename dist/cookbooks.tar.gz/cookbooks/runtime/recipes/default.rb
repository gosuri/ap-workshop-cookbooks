#
# Cookbook Name:: runtime
# Recipe:: default
#
# Copyright (c) 2014 The Authors, All Rights Reserved.
#
include_recipe "docker"
include_recipe "serf"
