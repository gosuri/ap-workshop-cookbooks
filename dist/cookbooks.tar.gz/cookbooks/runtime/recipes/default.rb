#
# Cookbook Name:: runtime
# Recipe:: default
#
# Copyright (c) 2014 The Authors, All Rights Reserved.
#
include_recipe "serf"
include_recipe "docker"
