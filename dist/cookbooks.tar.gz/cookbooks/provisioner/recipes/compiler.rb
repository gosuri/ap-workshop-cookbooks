# Recipe to install a compiler container that produces a runtime package for the application

# install and configure docker if missing
include_recipe "docker"

# create the directory to stage files 
# for the container
cachedir = "/var/containers/app-compiler"

# install bash sugar helper 
# remote_file "/usr/lib/bash-sugar.sh" do
#   source "https://raw.githubusercontent.com/gosuri/bash-sugar/master/lib/bash-sugar.sh"
# end

# # install compile script
# cookbook_file "/usr/local/bin/compile" do
#   mode "744"
# end

# execute "compile-app" do
#   command "#{cachedir}/compile #{node[:app][:repo]} #{cachedir}"
# end

# bash "copy-build" do
#   code <<-BASH
# id=$(docker run -d app-compiler)
# mkdir -p #{cachedir}/app-runtime
# rm -rf #{cachedir}/app-runtime/app
# docker cp $id:/app #{cachedir}/app-runtime
# docker stop $id
# docker rm $id
# BASH
# end
