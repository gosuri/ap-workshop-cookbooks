## 0.1.1

* Bugfix: Fix metadata from chef-docker copypasta

## 0.1.0

* Enhancement: [#1][]: Migrate AUFS handling from chef-docker aufs recipe

[#1]: https://github.com/bflad/chef-aufs/issues/1
