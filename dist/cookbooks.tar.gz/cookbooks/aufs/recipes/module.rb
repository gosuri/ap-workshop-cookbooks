modules 'aufs' do
  action :load
end
