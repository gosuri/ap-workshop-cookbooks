modules 'dm-mod' do
  action :load
end
