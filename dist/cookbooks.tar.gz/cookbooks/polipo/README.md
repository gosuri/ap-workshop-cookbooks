# Polipo cookbook

Install and configure polipo

## Infos

* Repository: https://github.com/hw-cookbooks/polipo
* IRC: Freenode @ #heavywater