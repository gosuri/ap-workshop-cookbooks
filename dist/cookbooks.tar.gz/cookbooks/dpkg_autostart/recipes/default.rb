# Dummy call to initialize resource
dpkg_autostart 'attribute_loader' do
  allow true
end
