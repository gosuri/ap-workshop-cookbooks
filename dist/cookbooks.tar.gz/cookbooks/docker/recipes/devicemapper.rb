# DEPRECATED: will likely be removed in chef-docker 1.0
include_recipe 'device-mapper'
