default[:serf][:cluster] = nil
default[:serf][:event_handlers] = nil
