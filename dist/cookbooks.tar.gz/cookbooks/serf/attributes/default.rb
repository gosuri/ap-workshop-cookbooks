default[:serf][:cluster] = nil
